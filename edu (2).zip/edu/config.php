<?php
$hostname="localhost";
$username="root";
$pass="";
$database="education";

$conn = mysqli_connect($hostname,$username,$pass,$database);
?>