
<!DOCTYPE html>
<html>

<head>
  <title>E2DUCATION About Us</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <!-- Popper JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
 <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

  <style>
   
    body {
      background: rgb(134, 172, 67);
      background: -moz-linear-gradient(352deg, rgba(134, 172, 67, 0.17970938375350143) 0%, rgba(24, 137, 180, 0.9612219887955182) 66%);
      background: -webkit-linear-gradient(352deg, rgba(134, 172, 67, 0.17970938375350143) 0%, rgba(24, 137, 180, 0.9612219887955182) 66%);
      background: linear-gradient(352deg, rgba(134, 172, 67, 0.17970938375350143) 0%, rgba(24, 137, 180, 0.9612219887955182) 66%);
      filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#86ac43", endColorstr="#1889b4", GradientType=1);
      font-size: 12px;
            background-repeat: no-repeat;
      height: 1000px;
    }

    #body{
      font-family: 'Montserrat', sans-serif;
    }

    .background {
      display: flex;
      background-repeat: no-repeat;
      height: 1000px;
    }

  
    .box {
      padding: 60px 0px;
    }

    .box-part {
      background: #FFF;
      border-radius: 0;
      padding: 60px 10px;
      margin: 30px 0px;
      border: 2px solid white;
      border-radius: 0.5em;
      box-shadow: 1px 2px 50px 0px rgba(0, 0, 0);
    }

    .text {
      margin: 20px 0px;
    }
  </style>
</head>


<body style="background-color: white">


  <div class="fluid-container">

<?php include 'navbar.php';?><br>

  

 <div class="box" style="margin-top: 100px">
      <div class="container">
       
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <div class="box-part text-center">

              <div class="title text-decoration">
                <h1>Our Web Portal</h1>
              <p class="pt-4">
                we employ Probabilistic Neural Network (PNN) with image and data processing techniques to implement a general purpose automated Plant identification for which user can analyze the growth rate of plant which is required in that entered area. The classification features are the set of time series values, built by the sequence of images, and geographic coordinate of field – latitude.

              </p>
              <p>
                It takes a lot of time and man power to identify the areas where plants are to be planted. People keep planting trees In the same area where plants are already been planted they do not have an idea where the need of plantation.

              </p>
              <p class="pt-4">
                we employ Probabilistic Neural Network (PNN) with image and data processing techniques to implement a general purpose automated Plant identification for which user can analyze the growth rate of plant which is required in that entered area. The classification features are the set of time series values, built by the sequence of images, and geographic coordinate of field – latitude.

              </p>
              <p>
                It takes a lot of time and man power to identify the areas where plants are to be planted. People keep planting trees In the same area where plants are already been planted they do not have an idea where the need of plantation.

              </p><p class="pt-4">
                we employ Probabilistic Neural Network (PNN) with image and data processing techniques to implement a general purpose automated Plant identification for which user can analyze the growth rate of plant which is required in that entered area. The classification features are the set of time series values, built by the sequence of images, and geographic coordinate of field – latitude.

              </p>
              <p>
                It takes a lot of time and man power to identify the areas where plants are to be planted. People keep planting trees In the same area where plants are already been planted they do not have an idea where the need of plantation.

              </p>
              </div>


            </div>
          </div>
        </div>
        
    </div>




  </div>

</div>

</body>


</html>